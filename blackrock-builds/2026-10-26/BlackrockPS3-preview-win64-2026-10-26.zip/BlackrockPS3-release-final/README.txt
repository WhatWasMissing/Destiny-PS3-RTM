Blackrock PS3 preview release (Windows x64)

Run blackrock-ps3.exe. Keep the data folder beside the executable.

Target: Destiny NPEB02021, APP_VER 01.24, build 51539.16.07.26.1808.v230, on PS3 HEN with webMAN MOD PS3MAPI.

Use TESTING > Port checks in the app to validate a live console connection.
