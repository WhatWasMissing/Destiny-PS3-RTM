# Blackrock PS3 — minimal source package

Build with Visual Studio 2022 (Desktop C++) and CMake 3.20+:

    cmake -S . -B build -G "Visual Studio 17 2022" -A x64
    cmake --build build --config Release -- /m:8

The executable and runtime data are copied to `out/`. This package contains only the files needed to build and run the Windows app: `src/`, `data/`, CMake, and the required Dear ImGui files. The game dump, research, alternate source snapshot, old build directories, and development tools are omitted.

Target: Destiny NPEB02021, APP_VER 01.24, build 51539.16.07.26.1808.v230, on PS3 HEN with webMAN MOD PS3MAPI. The developer's offline tests do not establish that ported features work on a live console; use the app's TESTING > Port checks workflow.
